"use strict";
exports.id = 482;
exports.ids = [482];
exports.modules = {

/***/ 7482:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AddQuestionForm)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6051);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_actions__WEBPACK_IMPORTED_MODULE_4__]);
_store_actions__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const { TextArea  } = antd__WEBPACK_IMPORTED_MODULE_2__.Input;
function AddQuestionForm({ onEditForm , editData , isAdmin  }) {
    const [form] = antd__WEBPACK_IMPORTED_MODULE_2__.Form.useForm();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const [api, contextHolder] = antd__WEBPACK_IMPORTED_MODULE_2__.notification.useNotification();
    const [classOptions, setClassOptions] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [teacherOptions, setTeacherOptions] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const onFinish = async (values)=>{
        const { class_id , teacher_id , answer , question_link , name , duration , total_question  } = values ?? {};
        if (!class_id) {
            api.warning({
                description: "Kelas tidak boleh kosong",
                placement: "topRight"
            });
            return;
        }
        if (isAdmin && !teacher_id) {
            api.warning({
                description: "Guru mapel tidak boleh kosong",
                placement: "topRight"
            });
            return;
        }
        if (onEditForm) {
            onEditForm(values);
            return;
        }
        if (answer.length < total_question) {
            return api.error({
                description: "Jumlah kunci jawaban kurang dari jumlah butir soal",
                placement: "topRight"
            });
        }
        const payload = class_id?.map((el)=>({
                name,
                total_question,
                duration,
                answer,
                question_link,
                teacher_id,
                class_id: el
            }));
        const { data: dataApi  } = await dispatch((0,_store_actions__WEBPACK_IMPORTED_MODULE_4__/* .bulkAddQuestion */ .du)(payload));
        if (dataApi) {
            api.success({
                description: dataApi.message,
                placement: "topRight"
            });
            if (isAdmin) {
                router.push("/admin/questionList");
            } else {
                router.push("/teacher/questionList");
            }
        } else {
            api.error({
                description: "Gagal menambahkan data. Coba lagi",
                placement: "topRight"
            });
        }
    };
    const fetchAllClass = async ()=>{
        const { data  } = await dispatch((0,_store_actions__WEBPACK_IMPORTED_MODULE_4__/* .getAllClass */ .F9)());
        if (data) {
            const newOptions = data?.class?.map((el)=>{
                return {
                    label: `${el.grade} ${el.name}`,
                    value: el.id
                };
            });
            setClassOptions(newOptions);
        }
    };
    const fetchAllTeacher = async ()=>{
        const { data  } = await dispatch((0,_store_actions__WEBPACK_IMPORTED_MODULE_4__/* .getAllTeacher */ .nP)());
        if (data) {
            const newOptions = data?.data?.map((el)=>{
                return {
                    label: el.full_name,
                    value: el.id
                };
            });
            setTeacherOptions(newOptions);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fetchAllClass();
        fetchAllTeacher();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (editData && onEditForm) {
            form.setFieldsValue(editData);
        }
    }, [
        onEditForm,
        editData
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            contextHolder,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_2__.Form, {
                onFinish: onFinish,
                form: form,
                layout: "vertical",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                        label: "Mata Pelajaran",
                        name: "name",
                        required: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Input, {
                            placeholder: "Mata Pelajaran",
                            required: true
                        })
                    }),
                    isAdmin ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                        label: "Guru Mata Pelajaran",
                        name: "teacher_id",
                        required: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Select, {
                            placeholder: "Guru Mapel",
                            options: teacherOptions
                        })
                    }) : null,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                        label: "Link Soal",
                        name: "question_link",
                        required: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Input, {
                            placeholder: "Link Soal",
                            required: true,
                            type: "link"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                        label: "Kunci Jawaban",
                        name: "answer",
                        required: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextArea, {
                            placeholder: "Mata Pelajaran",
                            required: true
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                        label: "Kelas",
                        name: "class_id",
                        required: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Select, {
                            placeholder: "Kelas",
                            options: classOptions,
                            mode: onEditForm ? "" : "multiple"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                        label: "Durasi",
                        name: "duration",
                        required: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.InputNumber, {
                            placeholder: "Durasi",
                            required: true,
                            min: 0,
                            step: 5
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                        label: "Jumlah Butir Soal",
                        name: "total_question",
                        required: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.InputNumber, {
                            placeholder: "Jumlah Butir Soal",
                            required: true,
                            min: 0
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Button, {
                            type: "primary",
                            htmlType: "submit",
                            children: "Simpan"
                        })
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;