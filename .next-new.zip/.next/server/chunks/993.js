exports.id = 993;
exports.ids = [993];
exports.modules = {

/***/ 7817:
/***/ ((module) => {

// Exports
module.exports = {
	"wrapper": "Layout_wrapper__PwD36"
};


/***/ }),

/***/ 1552:
/***/ ((module) => {

// Exports
module.exports = {
	"layoutContainer": "styles_layoutContainer__lszMh",
	"headerContainer": "styles_headerContainer__b_JCY",
	"popoverItem": "styles_popoverItem__y1Ogr",
	"barTitle": "styles_barTitle__m3VDP",
	"headerWrapper": "styles_headerWrapper__NIhgO",
	"titleContainer": "styles_titleContainer__lc22T",
	"avatarContainer": "styles_avatarContainer__GQD22",
	"dropdown": "styles_dropdown__efb5f",
	"dropdownContent": "styles_dropdownContent__QT6Zt",
	"headerItemList": "styles_headerItemList__Ob6zW",
	"dropdownItem": "styles_dropdownItem__Gb4tV"
};


/***/ }),

/***/ 4073:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _utils_apiHelper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7109);
/* harmony import */ var _utils_authHelper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1876);
/* harmony import */ var _constant_localStorage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5387);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

// import config from 'config';



class HttpService {
    constructor(){
        this.baseURL = "/api";
        this.authToken = (0,_utils_authHelper__WEBPACK_IMPORTED_MODULE_2__/* .getUserAuthToken */ .C8)();
        this.createAxiosInstance();
        this.axios.interceptors.response.use((response)=>response, (error)=>{
            if (error.response?.status === _utils_apiHelper__WEBPACK_IMPORTED_MODULE_1__/* .STATUS_CODES.ERROR.UNAUTHORIZED */ .j.ERROR.UNAUTHORIZED) {
                if (false) {}
            }
            return Promise.reject(error);
        });
    }
    refreshToken() {
        this.authToken = (0,_utils_authHelper__WEBPACK_IMPORTED_MODULE_2__/* .getUserAuthToken */ .C8)();
    }
    createAxiosInstance() {
        this.axios = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
            baseURL: this.baseURL ?? "",
            headers: {
                "auth-token": this.authToken ?? "",
                "Content-Type": "application/json"
            }
        });
    }
    setAuthTokenHeader(authToken) {
        this.authToken = authToken;
        this.createAxiosInstance();
    }
    removeAuthTokenHeader() {
        this.authToken = null;
        this.createAxiosInstance();
    }
    get(url, params) {
        return this.axios.get(url, params);
    }
    post(url, payload) {
        return this.axios.post(url, payload);
    }
    put(url, payload) {
        return this.axios.put(url, payload);
    }
    patch(url, payload) {
        return this.axios.patch(url, payload);
    }
    delete(url, payload) {
        return this.axios.delete(url, {
            baseURL: this.baseURL,
            headers: {
                "auth-token": this.authToken ?? "",
                "Content-Type": "application/json"
            },
            data: payload
        });
    }
}
const http = new HttpService();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (http);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3695:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _constant_apiPath__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5917);
/* harmony import */ var _constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_constant_apiPath__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constant_appConstant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4810);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var _http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4073);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__, _http__WEBPACK_IMPORTED_MODULE_2__]);
([axios__WEBPACK_IMPORTED_MODULE_1__, _http__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const base = "/api";
const getRequest = async (path, params)=>{
    try {
        return await axios.get(path, params);
    } catch (err) {
        return err;
    }
};
const postRequest = async (path, payload)=>{
    try {
        const res = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(path, payload);
        return res;
    } catch (err) {
        return err;
    }
};
const putRequest = async (path, payload)=>{
    try {
        const res = await axios.put(path, payload);
        return res;
    } catch (err) {
        return err;
    }
};
const patchRequest = async (path, payload)=>{
    try {
        return await axios.patch(path, payload);
    } catch (err) {
        return err;
    }
};
const deleteRequest = async (path)=>{
    try {
        return await axios.delete(path);
    } catch (err) {
        return err;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    auth: {
        login: (payload)=>postRequest(base + (_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().login), payload),
        getAuth: ()=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().getAuth))
    },
    token: {
        getOneToken: (token)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().token.getOneToken) + "/" + token),
        create: (payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().token.create), payload),
        delete: (id)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"]["delete"] */ .Z["delete"]((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().token["delete"]) + "/" + id),
        list: ()=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().token.list))
    },
    admin: {
        // * ========= Class ============
        addClass: (payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.addClass), payload),
        bulkAddClass: (payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.bulkAddClass), payload),
        getAllClass: ()=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.allClass)),
        editClass: (id, payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.editClass) + "/" + id, payload),
        deleteClass: (id)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"]["delete"] */ .Z["delete"]((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.deleteClass) + "/" + id),
        // * ========= student ============
        addStudent: (payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.addStudent), payload),
        bulkAddStudent: (payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.bulkAddStudent), payload),
        getAllStudent: (page, limit, search)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get(`${(_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.allStudent)}?page=${page ?? 0}&size=${limit ?? _constant_appConstant__WEBPACK_IMPORTED_MODULE_3__/* .PAGE_LIMIT */ .p}&search=${search ?? ""}`),
        editStudent: (id, payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.editStudent) + "/" + id, payload),
        deleteStudent: (id)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"]["delete"] */ .Z["delete"]((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.deleteStudent) + "/" + id),
        // * ========= teacher ============
        addTeacher: (payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.addTeacher), payload),
        bulkAddTeacher: (payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.bulkAddTeacher), payload),
        getAllTeacher: (page, limit, search)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get(`${(_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.allTeacher)}?page=${page ?? 0}&size=${limit ?? _constant_appConstant__WEBPACK_IMPORTED_MODULE_3__/* .PAGE_LIMIT */ .p}&search=${search ?? ""}`),
        editTeacher: (id, payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.editTeacher) + "/" + id, payload),
        deleteTeacher: (id)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"]["delete"] */ .Z["delete"]((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.deleteTeacher) + "/" + id),
        // * ========= question ============
        getAllQuestion: (params)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.allQuestion), {
                params
            }),
        // * ========= result ============
        deleteResult: (id)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"]["delete"] */ .Z["delete"]((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().admin.deleteResult) + "/" + id)
    },
    teacher: {
        addQuestion: (payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().teacher.addQuestion), payload),
        bulkAddQuestion: (payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().teacher.bulkAddQuestion), payload),
        getOneQuestion: (id)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().teacher.getOneQuestion) + "/" + id),
        getAllQuestion: ()=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().teacher.allQuestion)),
        editQuestion: (id, payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().teacher.editQuestion) + "/" + id, payload),
        deleteQuestion: (id)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"]["delete"] */ .Z["delete"]((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().teacher.deleteQuestion) + "/" + id),
        getAllClass: ()=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().teacher.allClass)),
        setQuestionStatus: (payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().teacher.changeStatus), payload)
    },
    student: {
        getResult: (id)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().student.getResult)),
        getAllQuestion: (id)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().student.allQuestion) + "/" + id),
        getOneQuestion: (id)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().student.getOneQuestion) + "/" + id),
        getStudentProfile: ()=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().student.profile)),
        initResult: (payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().student.initResult), payload),
        collectResult: (id, payload)=>_http__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post((_constant_apiPath__WEBPACK_IMPORTED_MODULE_0___default().student.collectResult) + "/" + id, payload)
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8355:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ CustomTable)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);



const CustomTable = ({ columns , data , pageSize , total , onChange  })=>{
    const pagination = {
        pageSize: pageSize ?? 10,
        total: total ?? 10
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Table, {
        columns: columns,
        dataSource: data,
        pagination: pagination,
        onChange: onChange
    });
};


/***/ }),

/***/ 722:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ DragDrop)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6302);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_4__);





const { Dragger  } = antd__WEBPACK_IMPORTED_MODULE_3__.Upload;
const DragDrop = ({ onDragDrop  })=>{
    const handleFileUpload = ({ file  })=>{
        const { status  } = file;
        const reader = new FileReader();
        reader.onload = (e)=>{
            const workbook = (0,xlsx__WEBPACK_IMPORTED_MODULE_4__.read)(e.target.result, {
                type: "binary"
            });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const data = xlsx__WEBPACK_IMPORTED_MODULE_4__.utils.sheet_to_json(worksheet, {
                header: 1
            });
            const result = data.slice(1).map((row)=>row.reduce((obj, value, index)=>{
                    obj[data[0][index]] = value;
                    return obj;
                }, {}));
            if (status === "done") {
                onDragDrop(result);
            }
        };
        reader.readAsBinaryString(file.originFileObj);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Dragger, {
            onChange: (e)=>handleFileUpload(e),
            showUploadList: true,
            multiple: false,
            accept: ".xlsx",
            maxCount: 1,
            beforeUpload: false,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "ant-upload-drag-icon",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__.InboxOutlined, {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "ant-upload-text",
                    children: "Click atau drag file ke area ini untuk mengupload"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "ant-upload-hint",
                    children: "Drag dan Drop hanya satu file dengan extention .xlsx"
                })
            ]
        })
    });
};


/***/ }),

/***/ 4394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ Heading)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);


function Heading({ title  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: title
        })
    });
}


/***/ }),

/***/ 7029:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ DefaultLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4394);
/* harmony import */ var _styles_Layout_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7817);
/* harmony import */ var _styles_Layout_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Layout_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils_authHelper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1876);






function DefaultLayout({ children , title  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const token = (0,_utils_authHelper__WEBPACK_IMPORTED_MODULE_4__/* .getUserAuthToken */ .C8)();
        if (!token) {
            router.push("/");
        }
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Head__WEBPACK_IMPORTED_MODULE_3__/* .Heading */ .X, {
                title: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Layout_module_css__WEBPACK_IMPORTED_MODULE_5___default().wrapper),
                children: children
            })
        ]
    });
}


/***/ }),

/***/ 9094:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ NavHeader)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1552);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);







function NavHeader({ barTitle  }) {
    const { Header  } = antd__WEBPACK_IMPORTED_MODULE_2__.Layout;
    const [showMenu, setShowMenu] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { token: { colorBgContainer  }  } = antd__WEBPACK_IMPORTED_MODULE_2__.theme.useToken();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const clickRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const content = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_styles_module_scss__WEBPACK_IMPORTED_MODULE_6___default().popoverItem),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_module_scss__WEBPACK_IMPORTED_MODULE_6___default().headerItemList),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_2__.Button, {
                danger: true,
                type: "text",
                onClick: ()=>{
                    localStorage.clear();
                    router.push("/");
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__.LogoutOutlined, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Log Out"
                    })
                ]
            })
        })
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        document.addEventListener("click", (e)=>{
            if (!clickRef?.current?.contains(e.target)) setShowMenu(false);
        }, true);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Header, {
        style: {
            padding: 0,
            background: colorBgContainer
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_styles_module_scss__WEBPACK_IMPORTED_MODULE_6___default().headerContainer),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_styles_module_scss__WEBPACK_IMPORTED_MODULE_6___default().titleContainer),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: (_styles_module_scss__WEBPACK_IMPORTED_MODULE_6___default().barTitle),
                        children: barTitle
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_styles_module_scss__WEBPACK_IMPORTED_MODULE_6___default().avatarContainer),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Popover, {
                        placement: "rightBottom",
                        content: content,
                        trigger: "click",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Avatar, {
                            shape: "square",
                            size: "large",
                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__.UserOutlined, {}),
                            onClick: ()=>setShowMenu(!showMenu),
                            ref: clickRef
                        })
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 2218:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ NavMenu)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _constant_appPath__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8184);
/* harmony import */ var _navItem__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7011);
/* harmony import */ var _utils_appHelper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9109);
/* harmony import */ var _store_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6051);
/* harmony import */ var _utils_authHelper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1876);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_actions__WEBPACK_IMPORTED_MODULE_8__]);
_store_actions__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










function NavMenu({ setBarTitle  }) {
    const { role  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)(({ common  })=>common);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { asPath  } = router;
    const [selectedMenu, setSelectedMenu] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("/");
    const [navItems, setNavItems] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setSelectedMenu(asPath);
    }, [
        asPath
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_utils_appHelper__WEBPACK_IMPORTED_MODULE_7__/* .handleBarTitle */ .h2)(window?.location?.pathname, (title)=>setBarTitle(title));
    }, [
        window?.location?.pathname
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (role) {
            if (role === "admin") {
                setNavItems(_navItem__WEBPACK_IMPORTED_MODULE_6__/* .admin */ .SA);
            } else if (role === "teacher") {
                setNavItems(_navItem__WEBPACK_IMPORTED_MODULE_6__/* .teacher */ .ex);
            } else if (role === "student") {
                setNavItems(_navItem__WEBPACK_IMPORTED_MODULE_6__/* .student */ .Pi);
            }
        } else {
            dispatch((0,_store_actions__WEBPACK_IMPORTED_MODULE_8__/* .fetchAuth */ .Mq)());
        }
    }, [
        role
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Menu, {
        style: {
            background: "transparent",
            color: "white"
        },
        mode: "inline",
        defaultSelectedKeys: [
            "/"
        ],
        selectedKeys: selectedMenu,
        items: navItems.map((item)=>({
                key: item.path,
                label: item.title,
                children: item?.children?.map((el)=>({
                        key: el.path,
                        label: el.title
                    }))
            })),
        onClick: ({ key  })=>{
            // handleBarTitle(key, (title) => setBarTitle(title));
            setSelectedMenu(key);
            router.push(key);
        }
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3872:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ SideBarLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _NavMenu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2218);
/* harmony import */ var _NavHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9094);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1552);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_module_scss__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_NavMenu__WEBPACK_IMPORTED_MODULE_4__]);
_NavMenu__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function SideBarLayout({ children  }) {
    const [barTitle, setBarTitle] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Dashboard");
    const { Content , Footer , Sider  } = antd__WEBPACK_IMPORTED_MODULE_2__.Layout;
    const { token: { colorBgContainer  }  } = antd__WEBPACK_IMPORTED_MODULE_2__.theme.useToken();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_2__.Layout, {
        className: (_styles_module_scss__WEBPACK_IMPORTED_MODULE_6___default().layoutContainer),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Sider, {
                breakpoint: "lg",
                collapsedWidth: "0",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_module_scss__WEBPACK_IMPORTED_MODULE_6___default().headerWrapper),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Image, {
                                alt: "logo",
                                src: "https://elearning.mipesrikdi.sch.id/__statics/upload/logo1656311603.png",
                                width: 50
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "MIPESRI CBT"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavMenu__WEBPACK_IMPORTED_MODULE_4__/* .NavMenu */ .M, {
                        setBarTitle: setBarTitle
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_2__.Layout, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavHeader__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        barTitle: barTitle
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Content, {
                        style: {
                            margin: "24px 16px 0"
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: {
                                padding: 24,
                                minHeight: 360,
                                background: colorBgContainer
                            },
                            children: children
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Footer, {
                        style: {
                            textAlign: "center"
                        },
                        children: "MI PESRI CBT \xa92023 Created by MI PESRI Kendari"
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7011:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pi": () => (/* binding */ student),
/* harmony export */   "SA": () => (/* binding */ admin),
/* harmony export */   "ex": () => (/* binding */ teacher)
/* harmony export */ });
/* harmony import */ var _constant_appPath__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8184);

const admin = [
    {
        key: "dashboard",
        title: "Dashboard",
        path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.dashboard */ .Z.admin.dashboard
    },
    {
        key: "class",
        title: "Data Kelas",
        children: [
            {
                key: "classList",
                title: "Daftar Kelas",
                path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.classList */ .Z.admin.classList
            },
            {
                key: "addClass",
                title: "Tambah Kelas",
                path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.addClass */ .Z.admin.addClass
            }
        ]
    },
    {
        key: "student",
        title: "Data Siswa",
        children: [
            {
                key: "studentList",
                title: "Daftar Siswa",
                path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.studentList */ .Z.admin.studentList
            },
            {
                key: "addStudent",
                title: "Tambah Siswa",
                path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.addStudent */ .Z.admin.addStudent
            }
        ]
    },
    {
        key: "teacher",
        title: "Data Guru",
        children: [
            {
                key: "teacherList",
                title: "Daftar Guru",
                path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.teacherList */ .Z.admin.teacherList
            },
            {
                key: "addTecher",
                title: "Tambah Guru",
                path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.addTeacher */ .Z.admin.addTeacher
            }
        ]
    },
    {
        key: "question",
        title: "Data Soal Ujian",
        children: [
            {
                key: "quextionList",
                title: "Daftar Soal Ujian",
                path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.questionList */ .Z.admin.questionList
            },
            {
                key: "addQuestion",
                title: "Tambah Soal Ujian",
                path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.addQuestion */ .Z.admin.addQuestion
            }
        ]
    },
    {
        key: "token",
        title: "Data Token",
        path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.createToken */ .Z.admin.createToken
    }
];
const teacher = [
    {
        key: "dashboard",
        title: "Dashboard",
        path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].teacher.dashboard */ .Z.teacher.dashboard
    },
    {
        key: "question",
        title: "Data Soal Ujian",
        children: [
            {
                key: "quextionList",
                title: "Daftar Soal Ujian",
                path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].teacher.questionList */ .Z.teacher.questionList
            },
            {
                key: "addQuestion",
                title: "Tambah Soal Ujian",
                path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].teacher.addQuestion */ .Z.teacher.addQuestion
            }
        ]
    }
];
const student = [
    {
        key: "dashboard",
        title: "Dashboard",
        path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].student.dashboard */ .Z.student.dashboard
    },
    {
        key: "exam",
        title: "Daftar Ujian",
        path: _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].student.exam */ .Z.student.exam
    }
];


/***/ }),

/***/ 8993:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Gi": () => (/* reexport safe */ _CustomTable__WEBPACK_IMPORTED_MODULE_3__.G),
/* harmony export */   "HQ": () => (/* reexport safe */ _Layouts__WEBPACK_IMPORTED_MODULE_1__.H),
/* harmony export */   "rU": () => (/* reexport safe */ _SideBarLayout__WEBPACK_IMPORTED_MODULE_2__.r),
/* harmony export */   "v0": () => (/* reexport safe */ _DragDrop__WEBPACK_IMPORTED_MODULE_4__.v)
/* harmony export */ });
/* harmony import */ var _Head__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4394);
/* harmony import */ var _Layouts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7029);
/* harmony import */ var _SideBarLayout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3872);
/* harmony import */ var _CustomTable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8355);
/* harmony import */ var _DragDrop__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(722);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_SideBarLayout__WEBPACK_IMPORTED_MODULE_2__]);
_SideBarLayout__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6151:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const actionTypes = {
    LOGIN: "LOGIN",
    IS_LOADING: "IS_LOADING",
    IS_ERROR: "IS_ERROR",
    IS_SUCCESS: "IS_SUCCESS",
    SET_ROLE: "SET_ROLE",
    LOGIN: "LOGIN",
    SET_PAGE_TITLE: "SET_PAGE_TITLE",
    ADD_CLASS: "ADD_CLASS",
    BULK_ADD_CLASS: "BULK_ADD_CLASS",
    ALL_CLASS: "ALL_CLASS",
    EDIT_CLASS: "EDIT_CLASS"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (actionTypes);


/***/ }),

/***/ 5917:
/***/ ((module) => {

"use strict";

const apiPath = {
    root: "/",
    login: "/login",
    register: "/register",
    getAuth: "/getAuth",
    token: {
        getOneToken: "/token/getOneToken",
        create: "/token/create",
        delete: "/token/delete",
        list: "/token/list"
    },
    admin: {
        addClass: "/admin/add-class",
        bulkAddClass: "/admin/bulk-add-class",
        allClass: "/admin/all-class",
        editClass: "/admin/edit-class",
        deleteClass: "admin/delete-class",
        addStudent: "/admin/add-student",
        bulkAddStudent: "/admin/bulk-add-student",
        allStudent: "/admin/all-student",
        editStudent: "/admin/edit-student",
        deleteStudent: "/admin/delete-student",
        addTeacher: "/admin/add-teacher",
        bulkAddTeacher: "/admin/bulk-add-teacher",
        allTeacher: "/admin/all-teacher",
        editTeacher: "/admin/edit-teacher",
        deleteTeacher: "/admin/delete-teacher",
        allQuestion: "/admin/all-question",
        deleteResult: "/admin/delete-result"
    },
    teacher: {
        getOneQuestion: "/teacher/one-question",
        allQuestion: "/teacher/all-question",
        allClass: "/teacher/all-class",
        addQuestion: "teacher/add-question",
        bulkAddQuestion: "teacher/bulk-add-question",
        editQuestion: "/teacher/edit-question",
        deleteQuestion: "/teacher/delete-question",
        changeStatus: "/teacher/change-status"
    },
    student: {
        allQuestion: "/student/all-question",
        profile: "/student/profile",
        getOneQuestion: "/student/one-question",
        initResult: "/student/init-result",
        collectResult: "/student/collect-result",
        getResult: "/student/get-result"
    },
    api: {
        token: {
            create: "/create",
            delete: "/delete/:id",
            list: "/list",
            getOneToken: "/getOneToken/:secret_token"
        },
        admin: {
            addClass: "/add-class",
            bulkAddClass: "/bulk-add-class",
            allClass: "/all-class",
            editClass: "/edit-class/:id",
            deleteClass: "/delete-class/:id",
            addStudent: "/add-student",
            bulkAddStudent: "/bulk-add-student",
            allStudent: "/all-student",
            editStudent: "/edit-student/:id",
            deleteStudent: "/delete-student/:id",
            addTeacher: "/add-teacher",
            bulkAddTeacher: "/bulk-add-teacher",
            allTeacher: "/all-teacher",
            editTeacher: "/edit-teacher/:id",
            deleteTeacher: "/delete-teacher/:id",
            allQuestion: "/all-question",
            deleteResult: "/delete-result/:id"
        },
        teacher: {
            getOneQuestion: "/one-question/:id",
            allQuestion: "/all-question",
            allClass: "/all-class",
            addQuestion: "/add-question",
            bulkAddQuestion: "/bulk-add-question",
            editQuestion: "/edit-question/:id",
            deleteQuestion: "/delete-question/:id",
            changeStatus: "/change-status"
        },
        student: {
            allQuestion: "/all-question/:class_id",
            getOneQuestion: "/one-question/:id",
            profile: "/profile",
            initResult: "/init-result",
            collectResult: "/collect-result/:id",
            getResult: "/get-result"
        }
    }
};
// export default apiPath;
module.exports = apiPath;


/***/ }),

/***/ 4810:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ PAGE_LIMIT)
/* harmony export */ });
const PAGE_LIMIT = 10;


/***/ }),

/***/ 8184:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const appPath = {
    admin: {
        dashboard: "/admin/dashboard",
        classList: "/admin/classList",
        addClass: "/admin/addClass",
        addTeacher: "/admin/addTeacher",
        teacherList: "/admin/teacherList",
        studentList: "/admin/studentList",
        addStudent: "/admin/addStudent",
        library: "/admin/library",
        createExam: "/admin/createExam",
        createToken: "/admin/createToken",
        addQuestion: "/admin/addQuestion",
        questionList: "/admin/questionList"
    },
    teacher: {
        dashboard: "/teacher/dashboard",
        addQuestion: "/teacher/addQuestion",
        questionList: "/teacher/questionList",
        questionResult: "/teacher/questionResult"
    },
    student: {
        dashboard: "/student/dashboard",
        exam: "/student/examList",
        result: "/student/examResult"
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (appPath);


/***/ }),

/***/ 5387:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const LS_KEYS = {
    AUTH_TOKEN_KEY: "cbt-auth-token",
    USER_DETAILS_KEY: "cbt-user-details",
    STUDENT_EXAM: "cbt-student-exam",
    STUDENT_EXAM_ANSWER: "cbt-student-exam-answer",
    STUDENT_EXAM_DURATION: "cbt-student-exam-duration",
    STUDENT_EXAM_QUESTION: "cbt-student-exam-question",
    STUDENT_EXAM_TOTAL_QUESTION: "cbt-student-exam-total-question",
    STUDENT_EXAM_RESULT_ID: "cbt-student-exam-result-id",
    STUDENT_EXAM_BLUR_COUNT: "cbt-student-exam-blur-count",
    STUDENT_EXAM_SS_COUNT: "cbt-student-exam-ss-count"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LS_KEYS);


/***/ }),

/***/ 6405:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F9": () => (/* binding */ getAllClass),
/* harmony export */   "Gi": () => (/* binding */ listToken),
/* harmony export */   "I3": () => (/* binding */ bulkAddTeacher),
/* harmony export */   "MA": () => (/* binding */ deleteStudent),
/* harmony export */   "MV": () => (/* binding */ deleteResult),
/* harmony export */   "OI": () => (/* binding */ adminGetAllQuestion),
/* harmony export */   "Q2": () => (/* binding */ deleteTeacher),
/* harmony export */   "V3": () => (/* binding */ createToken),
/* harmony export */   "ZB": () => (/* binding */ deleteClass),
/* harmony export */   "Zt": () => (/* binding */ editStudent),
/* harmony export */   "cn": () => (/* binding */ addClass),
/* harmony export */   "dp": () => (/* binding */ bulkAddStudent),
/* harmony export */   "gF": () => (/* binding */ editTeacher),
/* harmony export */   "n1": () => (/* binding */ bulkAddClass),
/* harmony export */   "nP": () => (/* binding */ getAllTeacher),
/* harmony export */   "pQ": () => (/* binding */ deleteToken),
/* harmony export */   "tS": () => (/* binding */ addStudent),
/* harmony export */   "uh": () => (/* binding */ addTeacher),
/* harmony export */   "v1": () => (/* binding */ editClass),
/* harmony export */   "xp": () => (/* binding */ getAllStudent)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3695);
/* harmony import */ var _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6151);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// * ======== Class ========
const addClass = (payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.addClass */ .Z.admin.addClass(payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const bulkAddClass = (payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.bulkAddClass */ .Z.admin.bulkAddClass(payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const getAllClass = ()=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.getAllClass */ .Z.admin.getAllClass();
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const editClass = (id, payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.editClass */ .Z.admin.editClass(id, payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const deleteClass = (id)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.deleteClass */ .Z.admin.deleteClass(id);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
// * ======== Student ========
const addStudent = (payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.addStudent */ .Z.admin.addStudent(payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const bulkAddStudent = (payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.bulkAddStudent */ .Z.admin.bulkAddStudent(payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const getAllStudent = (page, limit, search)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.getAllStudent */ .Z.admin.getAllStudent(page, limit, search);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const editStudent = (id, payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.editStudent */ .Z.admin.editStudent(id, payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const deleteStudent = (id)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.deleteStudent */ .Z.admin.deleteStudent(id);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
// * ======== Teacher ========
const addTeacher = (payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.addTeacher */ .Z.admin.addTeacher(payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const bulkAddTeacher = (payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.bulkAddTeacher */ .Z.admin.bulkAddTeacher(payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const getAllTeacher = (page, limit, search)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.getAllTeacher */ .Z.admin.getAllTeacher(page, limit, search);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const editTeacher = (id, payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.editTeacher */ .Z.admin.editTeacher(id, payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const deleteTeacher = (id)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.deleteTeacher */ .Z.admin.deleteTeacher(id);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const createToken = (token)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].token.create */ .Z.token.create(token);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const deleteToken = (id)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].token["delete"] */ .Z.token["delete"](id);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const listToken = ()=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].token.list */ .Z.token.list();
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const adminGetAllQuestion = (params)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.getAllQuestion */ .Z.admin.getAllQuestion(params);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const deleteResult = (id)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.deleteResult */ .Z.admin.deleteResult(id);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2483:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ fetchAuth),
/* harmony export */   "X": () => (/* binding */ fetchLogin)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3695);
/* harmony import */ var _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6151);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const fetchLogin = (payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , response: response1  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].auth.login */ .Z.auth.login(payload);
            if (data) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].SET_ROLE */ .Z.SET_ROLE,
                    payload: data.role
                });
                return {
                    data
                };
            } else {
                const { data: error  } = response1;
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: error
                });
                return {
                    error
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const fetchAuth = ()=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].auth.getAuth */ .Z.auth.getAuth();
            if (data) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].SET_ROLE */ .Z.SET_ROLE,
                    payload: data.role
                });
                return {
                    data
                };
            } else {
                const { data: error  } = response;
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: error
                });
                return null;
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6051:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F9": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.F9),
/* harmony export */   "Gi": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.Gi),
/* harmony export */   "I3": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.I3),
/* harmony export */   "Km": () => (/* reexport safe */ _teacher__WEBPACK_IMPORTED_MODULE_2__.Km),
/* harmony export */   "MA": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.MA),
/* harmony export */   "MV": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.MV),
/* harmony export */   "Mq": () => (/* reexport safe */ _default__WEBPACK_IMPORTED_MODULE_0__.M),
/* harmony export */   "OI": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.OI),
/* harmony export */   "Q2": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.Q2),
/* harmony export */   "V3": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.V3),
/* harmony export */   "WK": () => (/* reexport safe */ _teacher__WEBPACK_IMPORTED_MODULE_2__.WK),
/* harmony export */   "WW": () => (/* reexport safe */ _teacher__WEBPACK_IMPORTED_MODULE_2__.WW),
/* harmony export */   "XB": () => (/* reexport safe */ _default__WEBPACK_IMPORTED_MODULE_0__.X),
/* harmony export */   "ZB": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.ZB),
/* harmony export */   "Zt": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.Zt),
/* harmony export */   "cn": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.cn),
/* harmony export */   "dp": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.dp),
/* harmony export */   "du": () => (/* reexport safe */ _teacher__WEBPACK_IMPORTED_MODULE_2__.du),
/* harmony export */   "gF": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.gF),
/* harmony export */   "n1": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.n1),
/* harmony export */   "nP": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.nP),
/* harmony export */   "pQ": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.pQ),
/* harmony export */   "pX": () => (/* reexport safe */ _teacher__WEBPACK_IMPORTED_MODULE_2__.pX),
/* harmony export */   "si": () => (/* reexport safe */ _teacher__WEBPACK_IMPORTED_MODULE_2__.si),
/* harmony export */   "tS": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.tS),
/* harmony export */   "uh": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.uh),
/* harmony export */   "v1": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.v1),
/* harmony export */   "xp": () => (/* reexport safe */ _admin__WEBPACK_IMPORTED_MODULE_1__.xp)
/* harmony export */ });
/* harmony import */ var _default__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2483);
/* harmony import */ var _admin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6405);
/* harmony import */ var _teacher__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2814);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_default__WEBPACK_IMPORTED_MODULE_0__, _admin__WEBPACK_IMPORTED_MODULE_1__, _teacher__WEBPACK_IMPORTED_MODULE_2__]);
([_default__WEBPACK_IMPORTED_MODULE_0__, _admin__WEBPACK_IMPORTED_MODULE_1__, _teacher__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2814:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Km": () => (/* binding */ deleteQuestion),
/* harmony export */   "WK": () => (/* binding */ setQuestionStatus),
/* harmony export */   "WW": () => (/* binding */ editQuestion),
/* harmony export */   "du": () => (/* binding */ bulkAddQuestion),
/* harmony export */   "pX": () => (/* binding */ getAllQuestion),
/* harmony export */   "si": () => (/* binding */ getOneQuestion)
/* harmony export */ });
/* unused harmony exports addQuestion, teacherGetAllClass */
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3695);
/* harmony import */ var _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6151);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const addQuestion = (payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: actionTypes.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await api.teacher.addQuestion(payload);
            if (status === 200) {
                dispatch({
                    type: actionTypes.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: actionTypes.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: actionTypes.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: actionTypes.IS_LOADING,
                payload: false
            });
        }
    };
};
const bulkAddQuestion = (payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].teacher.bulkAddQuestion */ .Z.teacher.bulkAddQuestion(payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const getAllQuestion = ()=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].teacher.getAllQuestion */ .Z.teacher.getAllQuestion();
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const editQuestion = (id, payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].teacher.editQuestion */ .Z.teacher.editQuestion(id, payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const deleteQuestion = (id)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].teacher.deleteQuestion */ .Z.teacher.deleteQuestion(id);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const setQuestionStatus = (payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].teacher.setQuestionStatus */ .Z.teacher.setQuestionStatus(payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const getOneQuestion = (id)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].teacher.getOneQuestion */ .Z.teacher.getOneQuestion(id);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const teacherGetAllClass = ()=>{
    return async (dispatch)=>{
        dispatch({
            type: actionTypes.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await api.teacher.getAllClass();
            if (status === 200) {
                dispatch({
                    type: actionTypes.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: actionTypes.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: actionTypes.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: actionTypes.IS_LOADING,
                payload: false
            });
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ STATUS_CODES)
/* harmony export */ });
/* unused harmony export isSuccessfulRequest */
const STATUS_CODES = {
    // Success Codes
    SUCCESS: {
        OK: 200,
        CREATED: 201,
        NO_CONTENT: 204
    },
    // Error Codes
    ERROR: {
        UNAUTHORIZED: 401,
        SERVER_ERROR: 500
    }
};
const isSuccessfulRequest = (httpStatus)=>Object.entries(STATUS_CODES.SUCCESS).map(([key, val])=>val).includes(httpStatus);


/***/ }),

/***/ 9109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cu": () => (/* binding */ genRandonString),
/* harmony export */   "h2": () => (/* binding */ handleBarTitle),
/* harmony export */   "rD": () => (/* binding */ exportExcel)
/* harmony export */ });
/* harmony import */ var _constant_appPath__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8184);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6302);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_1__);


const handleBarTitle = (value, callback)=>{
    console.log("value: ", value);
    switch(value){
        case _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.dashboard */ .Z.admin.dashboard:
            if (callback) callback("Dashboard");
            break;
        case _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.classList */ .Z.admin.classList:
            if (callback) callback("Daftar Kelas");
            break;
        case _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.addClass */ .Z.admin.addClass:
            if (callback) callback("Tambah Kelas");
            break;
        case _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.teacherList */ .Z.admin.teacherList:
            if (callback) callback("Daftar Guru");
            break;
        case _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.addTeacher */ .Z.admin.addTeacher:
            if (callback) callback("Tambah Guru");
            break;
        case _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.studentList */ .Z.admin.studentList:
            if (callback) callback("Daftar Siswa");
            break;
        case _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.addStudent */ .Z.admin.addStudent:
            if (callback) callback("Tambah Siswa");
            break;
        case _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.createToken */ .Z.admin.createToken:
            if (callback) callback("Tambah Token");
            break;
        case _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].teacher.addQuestion */ .Z.teacher.addQuestion:
        case _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.addQuestion */ .Z.admin.addQuestion:
            if (callback) callback("Tambah Soal Ujian");
            break;
        case _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].teacher.questionList */ .Z.teacher.questionList:
        case _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].admin.questionList */ .Z.admin.questionList:
            if (callback) callback("List Soal Ujian");
            break;
        case _constant_appPath__WEBPACK_IMPORTED_MODULE_0__/* ["default"].student.exam */ .Z.student.exam:
            if (callback) callback("List Data Ujian");
            break;
        case "/student/examPage":
            if (callback) callback("Halaman Ujian");
            break;
        case "/student/examResult":
            if (callback) callback("Hasil Ujian");
            break;
        default:
            if (callback) callback("Dashboard");
            break;
    }
};
function genRandonString(length) {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let charLength = chars.length;
    let result = "";
    for(let i = 0; i < length; i++){
        result += chars.charAt(Math.floor(Math.random() * charLength));
    }
    return result;
}
function exportExcel(name, result) {
    const data = result.map((el)=>({
            NIS: el.nis,
            Nisn: el.nisn,
            Nama: el.name,
            Nilai: el.result
        }));
    const worksheet = xlsx__WEBPACK_IMPORTED_MODULE_1__.utils.json_to_sheet(data);
    const workbook = xlsx__WEBPACK_IMPORTED_MODULE_1__.utils.book_new();
    xlsx__WEBPACK_IMPORTED_MODULE_1__.utils.book_append_sheet(workbook, worksheet, "Sheet1");
    xlsx__WEBPACK_IMPORTED_MODULE_1__.writeFile(workbook, `${name}_data.xlsx`);
}


/***/ }),

/***/ 1876:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C8": () => (/* binding */ getUserAuthToken),
/* harmony export */   "PU": () => (/* binding */ setUserAuthToken)
/* harmony export */ });
/* unused harmony exports removeUserAuthToken, getLocalUserDetails, setLocalUserDetails, removeLocalUserDetails */
/* harmony import */ var _constant_localStorage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5387);

// Auth Token Helper
const getUserAuthToken = ()=>{
    if (false) {}
};
const setUserAuthToken = (authToken)=>{
    if (false) {}
};
const removeUserAuthToken = ()=>{
    if (false) {}
};
// User Details Helper
const getLocalUserDetails = ()=>{
    if (false) {}
};
const setLocalUserDetails = (userDetails)=>{
    if (false) {}
};
const removeLocalUserDetails = ()=>{
    if (false) {}
};


/***/ })

};
;