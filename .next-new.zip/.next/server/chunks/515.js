"use strict";
exports.id = 515;
exports.ids = [515];
exports.modules = {

/***/ 7515:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G6": () => (/* binding */ getOneToken),
/* harmony export */   "Iq": () => (/* binding */ studentGetAllQuestion),
/* harmony export */   "Ni": () => (/* binding */ getStudentProfile),
/* harmony export */   "Sg": () => (/* binding */ getResult),
/* harmony export */   "fg": () => (/* binding */ initResult),
/* harmony export */   "gS": () => (/* binding */ collectResult),
/* harmony export */   "si": () => (/* binding */ getOneQuestion)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3695);
/* harmony import */ var _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6151);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const getStudentProfile = ()=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].student.getStudentProfile */ .Z.student.getStudentProfile();
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const studentGetAllQuestion = (id)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].student.getAllQuestion */ .Z.student.getAllQuestion(id);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const getOneQuestion = ({ question_id  })=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].student.getOneQuestion */ .Z.student.getOneQuestion(question_id);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const getOneToken = (secret_token)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].token.getOneToken */ .Z.token.getOneToken(secret_token);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const initResult = (payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].student.initResult */ .Z.student.initResult(payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const collectResult = (id, payload)=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].student.collectResult */ .Z.student.collectResult(id, payload);
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};
const getResult = ()=>{
    return async (dispatch)=>{
        dispatch({
            type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
            payload: true
        });
        try {
            const { data , status  } = await _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].student.getResult */ .Z.student.getResult();
            if (status === 200) {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: null
                });
                return {
                    data
                };
            } else {
                dispatch({
                    type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                    payload: data
                });
                return {
                    error: data
                };
            }
        } catch (error) {
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_ERROR */ .Z.IS_ERROR,
                payload: error.message
            });
            return {
                error: error.message
            };
        } finally{
            dispatch({
                type: _constant_actionTypes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].IS_LOADING */ .Z.IS_LOADING,
                payload: false
            });
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;